<?php
/* API Name: DeleteEvents
   Parameter: intUdId,deviceToken,deviceType,userid,eventid
   Description: API will delete event details
 */

error_reporting(1);
require(APPPATH . '/libraries/REST_Controller.php');

class DeleteAdvertisement extends REST_Controller {

  function index(){

    $alldevices = $this->model_name->select_data_by_condition('hoo_devices',array('accessToken' => $this->input->post('accessToken') ), '*' ,'' , '' ,'', '', array());
    if( !empty($alldevices) ){

                $userid = $this->input->post('userid');
                $advid = $this->input->post('advid');

                /**  Check with username and password */
                $checkUser = $this->model_name->select_data_by_condition('hoo_users', array('id' => $userid), '*', '', '', '', '', array());
                if( !empty($checkUser) ){

                        $advDetails = $this->model_name->select_data_by_condition('hoo_advertisment', array('id' => $advid, 'is_delete' => '0'), '*', '', '', '', '', array());
                        if( !empty($advDetails) ){

                          $update_array = array(
                              "is_delete" => '1',
                          );

                          if( $this->model_name->update_data($update_array, 'hoo_advertisment', 'id', $advid) ){
                              header('Content-Type: application/json');
                              $error = array('status' => 'Success', 'errorcode' => '0', 'msg' => 'Advertisement details are deleted successfully');
                              echo json_encode($error);
                              exit;
      
                          }else{
                              header('Content-Type: application/json');
                              $error = array('status' => 'Failed', 'errorcode' => '1', 'msg' => 'Advertisement details are not deleted successfully');
                              echo json_encode($error);
                              exit;

                          }

                        }else{
                          header('Content-Type: application/json');
                          $error = array('status' => 'Failed', 'errorcode' => '2', 'msg' => 'No such event exists');
                          echo json_encode($error);
                          exit;

                      }
                        

                        
                    
                }else{
                    header('Content-Type: application/json');
                    $error = array('status' => 'Failed', 'errorcode' => '1', 'msg' => 'UserId is incorrect');
                    echo json_encode($error);
                    exit;


                }
           
    }else{
        header('Content-Type: application/json');
        $error = array('status' => 'Failed', 'errorcode' => '2', 'msg' => 'Access Token is incorrect');
        echo json_encode($error);
        exit;
    }

  }
}

?>